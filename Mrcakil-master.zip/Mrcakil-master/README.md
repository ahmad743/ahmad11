# PENTESTER TOOLS V2.1
# how to install
# git clone https://github.com/mrcakil/Mrcakil.git
# cd Mrcakil
# chmod 777 tools
# ./tools
# OR
# git clone https://github.com/mrcakil/Mrcakil.git
# cd Mrcakil
# chmod 777 tools2
# ./tools2

# CODED By: ./Mr.Cakil
# Thanks to : 4wsec - Mr.TenWap - all member official 99syndicate - All member official anonymous cyber team
# Contact Here : mrcakil@programmer.net
